A Editor Plugin for automatic doc generation through Doxygen
Author: Jacob Pennock (http://Jacobpennock.com)
Version: 1.0

Install it in Unity like any other plugin.
Go to: Window -> Documentation with Doxygen
Follow the prompts.

You can also configure more advanced settings 
of Doxygen by editing the file
Editor -> Doxygen -> Resources -> BaseDoxyfile